"use strict";

const SPEED_API_BASE = "https://api.speedracelight.com";
const TMDB_BASE = "https://api.themoviedb.org/3";
const TMDB_KEY = "307b7b8ef035c6aa336900aef4e203bd";
const REQUEST_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36",
    Origin: "https://www.vidking.net",
    Referer: "https://www.vidking.net/"
};
const SERVERS = [
    { name: "Hydrogen", endpoint: "cdn/sources-with-title" }
];

const ITIR = 8;
const SIZE = 61;
const RL = 2654435769;
const ENC = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580];
const INI_ENC = [1732584193, 4023233417, 2562383102, 271733878];
const SF = [109, 118, 109, 49];

function avalancheMix(value) {
    value >>>= 0;
    value ^= value >>> 16;
    value = Math.imul(value, 2246822507) >>> 0;
    value ^= value >>> 13;
    value = Math.imul(value, 3266489909) >>> 0;
    value ^= value >>> 16;
    return value >>> 0;
}

function rotateLeft(value, shift) {
    value >>>= 0;
    shift &= 31;
    return shift === 0 ? value >>> 0 : (value << shift | value >>> 32 - shift) >>> 0;
}

function computeSeedHash(seed) {
    let hash = INI_ENC[0] >>> 0;
    for (let index = 0; index < seed.length; index++) {
        hash = rotateLeft((hash ^ Math.imul(seed.charCodeAt(index), ENC[index & 15])) >>> 0, 5);
    }
    return avalancheMix(hash);
}

function buildPermutationTable(seed) {
    const state = new Array(256);
    for (let index = 0; index < 256; index++)
        state[index] = index;
    let cursor = 0;
    for (let index = 0; index < 256; index++) {
        cursor = cursor + state[index] + seed.charCodeAt(index % seed.length) & 255;
        const temporary = state[index];
        state[index] = state[cursor];
        state[cursor] = temporary;
    }
    return state;
}

function computeFnvHash(value) {
    let hash = 2166136261;
    for (let index = 0; index < value.length; index++) {
        hash = Math.imul(hash ^ value.charCodeAt(index), 16777619) >>> 0;
    }
    return avalancheMix(hash);
}

function combineWithMask(left, right, mask) {
    return ((left ^ right) >>> 0 | (left & right & mask) >>> 0) >>> 0;
}

function createCipher(seed, mediaId) {
    if ((seed.length * (seed.length + 1) & 1) === 1) {
        return { state: buildPermutationTable(seed), accumulator: computeSeedHash(seed) };
    }
    const state = new Array(SIZE);
    let accumulator = avalancheMix(computeFnvHash(seed) ^ avalancheMix(mediaId >>> 0 ^ RL)) >>> 0;
    for (let round = 0; round < ITIR; round++) {
        if ((round * (round + 1) & 1) === 0) {
            const index = accumulator % SIZE;
            accumulator = rotateLeft(accumulator + RL >>> 0, 7 + (round & 7));
            state[index] = (accumulator ^ avalancheMix(accumulator)) >>> 0;
            accumulator = avalancheMix(accumulator + index >>> 0);
        } else {
            state[round] = ENC[round & 15];
        }
    }
    return { state, accumulator: avalancheMix(accumulator ^ 2779096485) >>> 0 };
}

function generateNextCipherWord(cipher, index) {
    const state = cipher.state;
    let accumulator = cipher.accumulator;
    const stateIndex = accumulator % SIZE;
    const mask = 0 - Number(stateIndex in state);
    const stateValue = state[stateIndex] >>> 0;
    const offset = Math.imul(RL, index + 1) >>> 0;
    let value = combineWithMask(accumulator, (stateValue ^ offset) >>> 0, mask);
    value = (rotateLeft(value + accumulator >>> 0, stateIndex & 31) ^ rotateLeft(accumulator, Math.imul(stateIndex, 7) & 31)) >>> 0;
    accumulator = avalancheMix(value + RL >>> 0);
    state[stateIndex] = accumulator >>> 0;
    cipher.accumulator = accumulator;
    return accumulator >>> 0;
}

function deriveKeyStream(seed, mediaId, length) {
    const cipher = createCipher(seed, mediaId);
    const output = new Uint8Array(length);
    let wordIndex = 0;
    for (let index = 0; index < length;) {
        const word = generateNextCipherWord(cipher, wordIndex++);
        output[index++] = word & 255;
        if (index < length) output[index++] = word >>> 8 & 255;
        if (index < length) output[index++] = word >>> 16 & 255;
        if (index < length) output[index++] = word >>> 24 & 255;
    }
    return output;
}

function base64UrlDecode(value) {
    const normalized = value.replace(/-/g, "+").replace(/_/g, "/").padEnd(Math.ceil(value.length / 4) * 4, "=");
    const binary = atob(normalized);
    const bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index++) {
        bytes[index] = binary.charCodeAt(index);
    }
    return bytes;
}

function utf8Decode(bytes) {
    let output = "";
    for (let index = 0; index < bytes.length;) {
        const first = bytes[index++];
        if (first < 128) {
            output += String.fromCharCode(first);
        } else if (first < 224) {
            const second = bytes[index++];
            output += String.fromCharCode((first & 31) << 6 | second & 63);
        } else if (first < 240) {
            const second = bytes[index++];
            const third = bytes[index++];
            output += String.fromCharCode((first & 15) << 12 | (second & 63) << 6 | third & 63);
        } else {
            const second = bytes[index++];
            const third = bytes[index++];
            const fourth = bytes[index++];
            let codePoint = (first & 7) << 18 | (second & 63) << 12 | (third & 63) << 6 | fourth & 63;
            codePoint -= 65536;
            output += String.fromCharCode(55296 + (codePoint >> 10), 56320 + (codePoint & 1023));
        }
    }
    return output;
}

function decryptAndValidatePayload(payload, seed, mediaId) {
    const bytes = base64UrlDecode(payload);
    const keyStream = deriveKeyStream(seed, mediaId, bytes.length);
    for (let index = 0; index < bytes.length; index++) {
        bytes[index] ^= keyStream[index];
    }
    for (let index = 0; index < SF.length; index++) {
        if (bytes[index] !== SF[index]) throw new Error("Invalid response");
    }
    return utf8Decode(bytes.subarray(SF.length));
}

async function fetchJson(url, options) {
    const response = await fetch(url, options);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return response.json();
}

async function searchTmdb(query, mediaType) {
    const endpoint = mediaType === "tv" ? "search/tv" : "search/movie";
    const res = await fetch(`${TMDB_BASE}/${endpoint}?api_key=${TMDB_KEY}&query=${encodeURIComponent(query)}`);
    if (!res.ok) return [];
    const data = await res.json();
    return data.results || [];
}

async function fetchMetadata(tmdbId, mediaType) {
    const endpoint = mediaType === "tv" ? "tv" : "movie";
    const res = await fetch(`${TMDB_BASE}/${endpoint}/${tmdbId}?api_key=${TMDB_KEY}&append_to_response=external_ids`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    return {
        title: mediaType === "movie" ? data.title : data.name,
        year: String(new Date(mediaType === "movie" ? data.release_date : data.first_air_date).getFullYear() || ""),
        imdbId: data.external_ids && data.external_ids.imdb_id || ""
    };
}

function constructSourceUrl(server, request, seed) {
    const params = {
        title: request.title,
        mediaType: request.mediaType,
        year: request.year,
        episodeId: request.episode || "1",
        seasonId: request.season || "1",
        tmdbId: request.tmdbId,
        imdbId: request.imdbId,
        enc: "2",
        seed,
        _t: String(Date.now())
    };
    Object.assign(params, server.params || {});
    const query = Object.keys(params).map((key) => `${encodeURIComponent(key)}=${encodeURIComponent(params[key])}`).join("&");
    return `${SPEED_API_BASE}/${server.endpoint}?${query}`;
}

function normalizeSubtitles(subtitles) {
    if (!Array.isArray(subtitles)) return [];
    return subtitles.filter((subtitle) => subtitle && subtitle.url).map((subtitle) => ({
        url: subtitle.url,
        lang: subtitle.lang || subtitle.language || "und",
        label: subtitle.label || subtitle.display || subtitle.language || "Subtitle"
    }));
}

async function fetchServerSources(server, request, seed) {
    try {
        const response = await fetch(constructSourceUrl(server, request, seed), {
            headers: Object.assign({}, REQUEST_HEADERS, {
                "Cache-Control": "no-cache, no-store, must-revalidate",
                Pragma: "no-cache",
                Expires: "0"
            })
        });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const data = JSON.parse(decryptAndValidatePayload(await response.text(), seed, Number(request.tmdbId)));
        if (!data || !Array.isArray(data.sources)) return [];
        const sharedSubtitles = normalizeSubtitles(data.subtitles);
        return data.sources.filter((source) => source && source.url && (!server.qualityFilter || source.quality === server.qualityFilter)).map((source, index) => ({
            name: `VidKing • ${server.name}`,
            title: `VidKing • ${server.name}`,
            url: source.url,
            quality: source.quality || source.label || "1080P",
            type: source.type || (source.url.includes(".mpd") ? "application/dash+xml" : source.url.includes(".mp4") ? "video/mp4" : "application/x-mpegurl"),
            headers: Object.assign({}, REQUEST_HEADERS, source.headers || {}),
            subtitles: normalizeSubtitles(source.subtitles).concat(sharedSubtitles)
        }));
    } catch {
        return [];
    }
}

async function getStreams(tmdbIdOrSearch, mediaType, season, episode) {
    const normalizedType = mediaType === "series" ? "tv" : mediaType;

    let tmdbId = tmdbIdOrSearch;
    if (typeof tmdbIdOrSearch === 'string' && isNaN(parseInt(tmdbIdOrSearch))) {
        const searchResults = await searchTmdb(tmdbIdOrSearch, normalizedType);
        const matched = searchResults.find(r => r.title?.toLowerCase().includes(tmdbIdOrSearch.toLowerCase()) || r.name?.toLowerCase().includes(tmdbIdOrSearch.toLowerCase()));
        if (!matched) return [];
        tmdbId = matched.id;
    }

    if (!tmdbId || normalizedType !== "movie" && normalizedType !== "tv" || normalizedType === "tv" && (!season || !episode)) return [];
    try {
        const metadata = await fetchMetadata(tmdbId, normalizedType);
        const seedData = await fetchJson(`${SPEED_API_BASE}/seed?mediaId=${encodeURIComponent(String(tmdbId))}`, { headers: REQUEST_HEADERS });
        if (!seedData || !seedData.seed) return [];
        const request = {
            mediaType: normalizedType,
            tmdbId: String(tmdbId),
            season: String(season || 1),
            episode: String(episode || 1),
            title: metadata.title,
            year: metadata.year,
            imdbId: metadata.imdbId
        };
        const results = await Promise.all(SERVERS.map((server) => fetchServerSources(server, request, seedData.seed)));
        const streams = [].concat.apply([], results).filter((stream) => stream.quality === "1080p" || stream.quality === "2160p");
        const final = {};
        return streams.filter((stream) => {
            if (final[stream.url]) return false;
            final[stream.url] = true;
            return true;
        });
    } catch {
        return [];
    }
}

module.exports = { getStreams };