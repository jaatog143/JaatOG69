"use strict"

const TMDB_API_KEY = "307b7b8ef035c6aa336900aef4e203bd";
const DOMAINS_URL = "https://gitea.com/eclipsia-404/404/raw/branch/main/urls.json";
const FALLBACK_URL = "https://banglaplex.click";
const HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36"
};

let cachedDomain = null;

async function getMainUrl() {
    if (cachedDomain) return cachedDomain;
    try {
        const res = await fetch(DOMAINS_URL, { skipSizeCheck: true });
        const data = await res.json();
        cachedDomain = data && data.Banglaplex || FALLBACK_URL;
    } catch (e) {
        cachedDomain = FALLBACK_URL;
    }
    return cachedDomain;
}

function extractQuality(str) {
    const u = (str || "").toLowerCase();
    if (u.includes("2160p") || u.includes("4k")) return "4K";
    if (u.includes("1080p")) return "1080p";
    if (u.includes("720p")) return "720p";
    if (u.includes("480p")) return "480p";
    if (u.includes("360p")) return "360p";
    return "Unknown";
}

function unpackJs(packed) {
    const m = packed.match(/}\('(.*)',\s*(\d+|\[\]),\s*(\d+),\s*'(.*)'\.split\('\|'\)/);
    if (!m) return null;
    let [, payload, radixStr, countStr, wordsStr] = m;
    const radix = parseInt(radixStr) || 36;
    const count = parseInt(countStr);
    const words = wordsStr.split("|");
    const dict = {};
    for (let i = 0; i < count; i++) {
        const key = i.toString(radix);
        dict[key] = words[i] || key;
    }
    return payload.replace(/\b\w+\b/g, (w) => dict[w] || w);
}

async function extractStreamwishHG(url, referer) {
    try {
        const res = await fetch(url, { headers: { ...HEADERS, Referer: referer || url }, skipSizeCheck: true });
        const html = await res.text();
        const packedMatch = html.match(/eval\(function\(p,a,c,k,e,d\)[\s\S]*?\)\)\)/);
        const unpacked = packedMatch ? unpackJs(packedMatch[0]) : html;
        if (!unpacked) return [];
        const fileMatch = unpacked.match(/file:"(.*?)"/) || unpacked.match(/sources:\s*\[\{\s*file:\s*"([^"]+)"/);
        if (!fileMatch) return [];
        const fileUrl = fileMatch[1];
        return [{
            url: (fileUrl.startsWith("//") ? "https:" + fileUrl : fileUrl).trim(),
            quality: extractQuality(fileUrl),
            name: "Streamwish",
            headers: { Referer: url },
            subtitles: []
        }];
    } catch (e) {
        return [];
    }
}

async function extractIplayerhls(url, referer) {
    try {
        const res = await fetch(url, { headers: { ...HEADERS, Referer: referer || url }, skipSizeCheck: true });
        const html = await res.text();
        const packedMatch = html.match(/eval\(function\(p,a,c,k,e,d\)[\s\S]*?\)\)\)/);
        const unpacked = packedMatch ? unpackJs(packedMatch[0]) : html;
        if (!unpacked) return [];
        const fileMatch = unpacked.match(/sources:\[\{file:"(.*?)"/) || unpacked.match(/file:"(.*?)"/);
        if (!fileMatch) return [];
        const fileUrl = fileMatch[1];
        return [{
            url: (fileUrl.startsWith("//") ? "https:" + fileUrl : fileUrl).trim(),
            quality: extractQuality(fileUrl),
            name: "Iplayerhls",
            headers: { Referer: url },
            subtitles: []
        }];
    } catch (e) {
        return [];
    }
}

async function extractRpmvid(url, referer) {
    try {
        const res = await fetch(url, { headers: { ...HEADERS, Referer: referer || url }, skipSizeCheck: true });
        const html = await res.text();
        const m3u8Match = html.match(/file\s*:\s*["'](https?:\/\/[^"']+\.m3u8[^"']*)["']/)
            || html.match(/source\s+src=["'](https?:\/\/[^"']+\.m3u8[^"']*)["']/)
            || html.match(/["'](https?:\/\/[^"']+\.m3u8[^"']*)["']/);
        if (!m3u8Match) return [];
        return [{
            url: m3u8Match[1].trim(),
            quality: extractQuality(m3u8Match[1]),
            name: "Rpmvid",
            headers: { Referer: url },
            subtitles: []
        }];
    } catch (e) {
        return [];
    }
}

async function extractBanglaPlex(url, referer) {
    try {
        const res = await fetch(url, { headers: { ...HEADERS, Referer: referer || url }, skipSizeCheck: true });
        const html = await res.text();
        const $ = cheerio.load(html);
        let directHref = null;
        $("div.vd a.btn-primary").each((i, el) => {
            if (directHref) return;
            if (/Generate Direct/i.test($(el).text())) directHref = $(el).attr("href");
        });
        if (!directHref) return [];
        const directUrl = directHref.startsWith("http") ? directHref : new URL(directHref, url).toString();
        const linksRes = await fetch(directUrl, { headers: { ...HEADERS, Referer: url }, skipSizeCheck: true });
        const linksHtml = await linksRes.text();
        const $links = cheerio.load(linksHtml);
        const streams = [];
        const iframeSrc = $links("iframe").attr("src");
        if (iframeSrc) {
            streams.push({
                url: iframeSrc,
                quality: extractQuality(iframeSrc),
                name: "BanglaPlex",
                headers: { Referer: directUrl },
                subtitles: []
            });
        }
        $links("h2 a.btn").each((i, el) => {
            const href = $links(el).attr("href");
            if (href) {
                const btnText = $links(el).text().trim() || "";
                const resolvedUrl = href.startsWith("http") ? href : new URL(href, directUrl).toString();
                const quality = btnText || extractQuality(resolvedUrl);
                streams.push({
                    name: "BanglaPlex",
                    quality: "1080P",
                    url: resolvedUrl,
                    headers: { Referer: directUrl },
                    subtitles: []
                });
            }
        });
        return streams;
    } catch (e) {
        return [];
    }
}

async function extractPlextream(url, referer) {
    try {
        const res = await fetch(url, { headers: { ...HEADERS, Referer: referer || url }, skipSizeCheck: true });
        const html = await res.text();
        const $ = cheerio.load(html);
        const streams = [];
        const buttons = $(".menu-card button").toArray();
        for (const btn of buttons) {
            const onclick = $(btn).attr("onclick") || "";
            const m = onclick.match(/changeServer\('([^']*)'/);
            if (!m || !m[1]) continue;
            const videoUrl = m[1];
            if (!videoUrl.trim()) continue;
            if (/rpmvid|rpmshare|strp2p/i.test(videoUrl)) {
                streams.push(...await extractGenericVidStack(videoUrl, referer));
            } else {
                streams.push(...await dispatchExtractor(videoUrl, referer));
            }
        }
        return streams;
    } catch (e) {
        return [];
    }
}

async function extractGenericVidStack(url, referer) {
    try {
        const res = await fetch(url, { headers: { ...HEADERS, Referer: referer || url }, skipSizeCheck: true });
        const html = await res.text();
        const m3u8Match = html.match(/file\s*:\s*["'](https?:\/\/[^"']+\.m3u8[^"']*)["']/)
            || html.match(/<source[^>]+src=["'](https?:\/\/[^"']+\.m3u8[^"']*)["']/)
            || html.match(/["'](https?:\/\/[^"']+\.m3u8[^"']*)["']/);
        if (!m3u8Match) return [];
        return [{
            url: m3u8Match[1].trim(),
            quality: extractQuality(m3u8Match[1]),
            name: "VidStack",
            headers: { Referer: url },
            subtitles: []
        }];
    } catch (e) {
        return [];
    }
}

async function dispatchExtractor(url, referer) {
    try {
        const host = new URL(url).hostname;
        if (host.includes("xcloud")) return extractBanglaPlex(url, referer);
        if (host.includes("hglink")) return extractStreamwishHG(url, referer);
        if (host.includes("iplayerhls")) return extractIplayerhls(url, referer);
        if (host.includes("rpmvid")) return extractRpmvid(url, referer);
        if (host.includes("plextream")) return extractPlextream(url, referer);
        return extractGenericVidStack(url, referer);
    } catch (e) {
        return [];
    }
}

async function resolveImdbToTmdb(imdbId, mediaType) {
    try {
        const url = `https://api.themoviedb.org/3/find/${imdbId}?api_key=${TMDB_API_KEY}&external_source=imdb_id`;
        const data = await (await fetch(url, { skipSizeCheck: true })).json();
        const results = mediaType === "tv" ? data.tv_results : data.movie_results;
        return results && results.length ? results[0].id : null;
    } catch (e) {
        return null;
    }
}

async function getStreams(tmdbId, mediaType, season, episode) {
    try {
        if (typeof tmdbId === "string" && tmdbId.trim().toLowerCase().startsWith("tt")) {
            tmdbId = await resolveImdbToTmdb(tmdbId, mediaType);
            if (!tmdbId) return [];
        }
        if (mediaType !== "movie") return [];
        const mainUrl = await getMainUrl();
        const tmdbUrl = `https://api.themoviedb.org/3/${mediaType}/${tmdbId}?api_key=${TMDB_API_KEY}`;
        const mediaInfo = await (await fetch(tmdbUrl, { skipSizeCheck: true })).json();
        const title = mediaInfo.title || mediaInfo.name;
        if (!title) return [];
        const searchUrl = `${mainUrl}/search?q=${encodeURIComponent(title)}`;
        const searchHtml = await (await fetch(searchUrl, { headers: HEADERS, skipSizeCheck: true })).text();
        const $ = cheerio.load(searchHtml);
        const results = [];
        $("div.movie-container > div.col-md-2").each((i, el) => {
            const a = $(el).find("div.movie-img > div.movie-title > h3 > a");
            const href = a.attr("href");
            const t = a.text().trim();
            if (href) results.push({ title: t, url: href });
        });
        if (!results.length) return [];
        const lcTitle = title.toLowerCase();
        const match = results.find((r) => r.title.toLowerCase().includes(lcTitle)) || results[0];
        const movieUrl = match.url.startsWith("http") ? match.url : `${mainUrl}${match.url.startsWith("/") ? "" : "/"}${match.url}`;
        const movieHtml = await (await fetch(movieUrl, { headers: HEADERS, skipSizeCheck: true })).text();
        const $movie = cheerio.load(movieHtml);
        const streams = [];
        const dispatchedUrls = new Set();

        async function safeDispatch(href, referer, serverLabel) {
            if (!href || dispatchedUrls.has(href)) return;
            dispatchedUrls.add(href);
            let extracted;
            if (href.toLowerCase().includes("xcloud")) {
                extracted = await extractBanglaPlex(href, referer);
            } else {
                extracted = await dispatchExtractor(href, referer);
            }
            if (serverLabel) {
                extracted = extracted.map(s => ({ ...s, quality: serverLabel }));
            }
            streams.push(...extracted);
        }

        const iframeSrc = $movie("div.video-embed-container > iframe").attr("src");
        if (iframeSrc) await safeDispatch(iframeSrc, mainUrl, null);

        const downloadHref = $movie("#download a").attr("href");
        if (downloadHref) {
            try {
                const dlUrl = downloadHref.startsWith("http") ? downloadHref : `${mainUrl}${downloadHref.startsWith("/") ? "" : "/"}${downloadHref}`;
                const tokenRes = await fetch(dlUrl, { headers: HEADERS, skipSizeCheck: true });
                const tokenHtml = await tokenRes.text();
                const $token = cheerio.load(tokenHtml);
                const input = $token("form input").first();
                const csrfName = input.attr("name");
                const csrfValue = input.attr("value");
                const postBody = new URLSearchParams();
                if (csrfName) postBody.set(csrfName, csrfValue || "");
                const postRes = await fetch(dlUrl, {
                    method: "POST",
                    headers: { ...HEADERS, "Content-Type": "application/x-www-form-urlencoded" },
                    body: postBody.toString(),
                    skipSizeCheck: true
                });
                const postHtml = await postRes.text();
                const $post = cheerio.load(postHtml);
                for (const el of $post("div.row > div.col-sm-8 > a").toArray()) {
                    const href = $post(el).attr("href");
                    const serverLabel = $post(el).text().trim();
                    await safeDispatch(href, dlUrl, serverLabel);
                }
            } catch (e) { }
        }

        const pathMap = {};
        const unique = [];
        for (const s of streams) {
            try {
                const key = new URL(s.url.trim()).pathname;
                if (!pathMap[key]) {
                    pathMap[key] = true;
                    unique.push(s);
                }
            } catch (e) {
                unique.push(s);
            }
        }
        return unique.slice(0, 2).map((s, i) => ({
            ...s,
            title,
            name: `BanglaPlex • Server ${i + 1}`,
            quality: "1080P"
        }));
    } catch (e) {
        return [];
    }
}

global.getStreams = getStreams;