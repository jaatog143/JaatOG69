"use strict";

const BASE_URL = "https://ballerinacappuccinalovestungtungtungsahur.com";
const REFERER = "https://player.vidlove.cc/";
const TMDB_BASE = "https://api.themoviedb.org/3";
const TMDB_KEY = "307b7b8ef035c6aa336900aef4e203bd";
const MIN_QUALITY = 1080;
const DEFAULT_QUALITY = "1080p";

const PROVIDERS = [
    "moviebox", "ipcloud", "tcloud", "vidapi", "vixsrc",
    "1embed", "xpass", "vidrift", "lookmovie", "vidnest"
];

const DEFAULT_HEADERS = {
    "accept": "application/json",
    "accept-language": "nl-NL,nl;q=0.9,en-US;q=0.8,en;q=0.7",
    "sec-ch-ua": "\"Not;A=Brand\";v=\"8\", \"Chromium\";v=\"150\", \"Google Chrome\";v=\"150\"",
    "Referer": REFERER
};

const parseQuality = (quality) => {
    const match = quality?.match(/(\d+)/);
    return match ? parseInt(match[1], 10) : 0;
};

const normalizeQuality = (quality) => {
    const q = String(quality || "").trim();
    return q ? q : DEFAULT_QUALITY;
};

const isQualityAcceptable = (quality) => {
    const resolved = normalizeQuality(quality);
    return parseQuality(resolved) >= MIN_QUALITY;
};

const resolveTitle = ({ name, title, original_title, original_name } = {}) =>
    name ?? title ?? original_title ?? original_name ?? "";

const buildEndpointUrl = (type, tmdbId, provider, season, episode) => {
    const params = new URLSearchParams({ id: tmdbId, mode: "json", sources: provider, hevc: "1" });
    if (season) params.set("season", season);
    if (episode) params.set("episode", episode);
    return `${BASE_URL}/${type}?${params}`;
};

const mapQualityToStream = (q, label, title) => ({
    name: `Vidlove • ${label}`,
    title: `Vidlove • ${label}`,
    url: q.url,
    quality: normalizeQuality(q.quality),
    size: "",
    type: "direct",
    headers: { Referer: REFERER },
    provider: "vidlove",
    filename: q.url,
});

async function searchTmdb(query, mediaType) {
    const endpoint = mediaType === "tv" ? "search/tv" : "search/movie";
    const res = await fetch(`${TMDB_BASE}/${endpoint}?api_key=${TMDB_KEY}&query=${encodeURIComponent(query)}`);
    if (!res.ok) return [];
    const data = await res.json();
    return data.results || [];
}

async function fetchProviderStreams(provider, tmdbId, type, season, episode) {
    try {
        const res = await fetch(buildEndpointUrl(type, tmdbId, provider, season, episode), {
            method: "GET",
            headers: DEFAULT_HEADERS
        });

        const { source, meta } = await res.json();

        if (!source) return [];

        const qualities = Array.isArray(source.qualities) ? source.qualities : [];
        const hasQualities = qualities.length > 0;
        const label = source.label ?? provider;
        const title = resolveTitle(meta);

        if (hasQualities) {
            return qualities
                .filter(q => q?.url && isQualityAcceptable(q.quality))
                .map(q => mapQualityToStream(q, label, title));
        }

        if (source.url) {
            return [{
                name: `Vidlove • ${label}`,
                title: `Vidlove • ${label}`,
                url: source.url,
                quality: normalizeQuality(source.quality),
                size: "",
                type: "direct",
                headers: { Referer: REFERER },
                provider: "vidlove",
                filename: source.url,
            }];
        }

        return [];
    } catch {
        return [];
    }
}

async function getStreams(tmdbIdOrSearch, type, season = null, episode = null) {
    let tmdbId = tmdbIdOrSearch;
    if (typeof tmdbIdOrSearch === 'string' && isNaN(parseInt(tmdbIdOrSearch))) {
        const searchResults = await searchTmdb(tmdbIdOrSearch, type);
        const matched = searchResults.find(r => r.title?.toLowerCase().includes(tmdbIdOrSearch.toLowerCase()) || r.name?.toLowerCase().includes(tmdbIdOrSearch.toLowerCase()));
        if (!matched) return [];
        tmdbId = matched.id;
    }

    const streams = await Promise.all(
        PROVIDERS.map(provider => fetchProviderStreams(provider, tmdbId, type, season, episode))
    );

    return streams.flat();
}

module.exports = { getStreams };